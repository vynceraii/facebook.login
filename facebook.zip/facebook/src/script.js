document.getElementById('loginForm').addEventListener('submit', function(e){
    e.preventDefault();

    let user = document.getElementById('username').value;
    let pass = document.getElementById('password').value;

    console.log("Captured (for demo):", user, pass);
    alert("Demo complete! Check console for what you typed.");
});